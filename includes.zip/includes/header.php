<div class="container-fluid topHeader">
    <div class="container p-0">
      <div class="emailHeader">
        <h5>Email : <span> <a href="mailto:contact@infinitybrains.com">contact@infinitybrains.com</span></a></h5>
      </div>
      <nav class="p-0 navbar navbar-expand-md pt-lg-0">
        <a href="index.php" class="navbar-brand"><img src="./images/IB_logo_for_web (1).svg" alt=""></a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#menu">
          <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
        </button>
        <div class="collapse navbar-collapse " id="menu">

          <ul class="ml-auto navbar-nav">
            <li class="nav-item">
              <a href="index.php" class="nav-link">Home</a>
            </li>

            <li class="nav-item">
              <a href="about.php" class="nav-link">About</a>
            </li>


            <li class="nav-item dropdown">
              <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">Service</a>
              <ul>
                <div class="dropdown-menu">
                  <li class="nav-item">
                    <a href="service_development.php" class="nav-link">Web Development</a>
                  </li>

                  <li class="nav-item">
                    <a href="service_mobile.php" class="nav-link">Mobile Development</a>
                  </li>

                  <li class="nav-item">
                    <a href="service_hybrid.php" class="nav-link">Hybrid Development</a>
                  </li>

                  <li class="nav-item">
                    <a href="service_digital.php" class="nav-link">Digital Maketing</a>
                  </li>

                  <li class="nav-item">
                    <a href="service_design.php" class="nav-link">Graphics & UI/UX Design</a>
                  </li>

                  <li class="nav-item">
                    <a href="service_content.php" class="nav-link">Content Writing</a>
                  </li>
                </div>
              </ul>
            </li>

            <li class="nav-item">
              <a href="portfolio.php" class="nav-link">Portfolio</a>
            </li>
            
            <li class="nav-item">
              <a href="https://careers.infinitybrains.com/" class="nav-link">Career</a>
              <!--<a href="careers.php" class="nav-link">Career</a>--> 
            </li>
            

            <li class="nav-item">
              <a href="contactus.php" class="nav-link">Contact</a>
            </li>

            <li class="nav-item">
              <a href="quote.php" class="nav-link link-button">Get Quote</a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
</div>


