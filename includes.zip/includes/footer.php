<section>
    <footer>
  <div class="text-grey container-fluid bg-dark">
    
    <div class="heading__1main">
      <h1 class="text-white heading__1">Contact Us</h1>
    </div>

    <div class="text-white row">
      <div class="col-lg-3">
        <div>
          <h1 class="heading_2 text-white">Contact us</h1>
        </div>

        <div>
          <span><i class="fas fa-map-marker-alt"></i></span>
          <strong> Address : </strong>
          <address><p>408, Luxuria Business Hub,Nr VR Mall, Vesu, Surat, Gujarat</p></address>
        </div>

        <div>
          <span><i class="fas fa-phone-alt"></i></span>
          <strong> Phone : </strong>
          <address><a href="tel:+91 942-673-4485"><p> +91 942-673-4485</p></a></address>
        </div>

        <div>
          <span><i class="fas fa-envelope-open-text"></i></span
          ><strong> Email : </strong>
          <address><a href="mailto:contact@infinitybrains.com" style="text-decoration: none; color: white;"><p>contact@infinitybrains.com</p> </a></address>
        </div>
      </div>

      <div class="col-lg-3">
        <h2 class="heading_2 text-white">Infinity Brains</h2>
        <p class="heading__desp text-grey">Infinity Brains is an accredited IT company, which is a venture of Redjinni Industries Pvt.
          Ltd. & taking projects from all over India, with the latest technologies & digitally
          transforming all kinds of business. We believe in building and maintaining long term
          relationships with all our clients.</p>
      </div>

      <div class="col-lg-3">
        <h2 class="heading_2 text-white">Quick Links</h2>
        <ul class="heading__desp">
          <li><a href="https://infinitybrains.com/">Home</a></li>
          <li><a href="https://infinitybrains.com/about.php">About Us</a></li>
          <li><a href="https://infinitybrains.com/portfolio.php">Portfolio</a></li>
          <li><a href="https://careers.infinitybrains.com/">Career</a></li>
          <li><a href="https://infinitybrains.com/contactus.php">Contact</a></li>
        </ul>
      </div>

      <div class="col-lg-3">
        <h2 class="heading_2 text-white">Our Services</h2>
        <ul class="heading__desp">
          <li><a href="https://infinitybrains.com/service_development.php">Web Development</a></li>
          <li><a href="https://infinitybrains.com/service_mobile.php">Mobile Development</a></li>
          <li><a href="https://infinitybrains.com/service_design.php">Web And UI/UX Design</a></li>
          <li><a href="https://infinitybrains.com/service_hybrid.php">Hybrid Development</a></li>
          <li><a href="https://infinitybrains.com/service_digital.php">Digital Services</a></li>
        </ul>
      </div>
    </div>

  </div>
</footer>
</section>

<section>
  <div class="container-fluid socialmedia">
    <div class="container-fluid socialmedia">
      <div class="socialIconFooter">
          <a href="https://www.facebook.com/Infinitybrainsindia" target="_blank"><i class="fab fa-facebook"></i></a>
          <a href="https://www.infinitybrains.com" target="_blank"><i class="fab fa-dribbble"></i></a>
          <a href="www.linkedin.com/company/infinity-brains" target="_blank"><i class="fab fa-linkedin-in"></i></a>
          <a href="contact@infinitybrains.com" target="_blank"><i class="far fa-envelope"></i></a>
        </div>
  
    </div>

  </div>
</section>